﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace herança
{
    class TotalizadorDeContas
    {
        //questão 8
        public double SaldoTotal { get; private set; }

        public void Adiciona(Conta conta)
        {
            SaldoTotal += conta.Saldo;
        }

    }

}
