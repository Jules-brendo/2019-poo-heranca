﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace herança

{
    class Conta
        {
            public int Numero { get; set; }
            public double Saldo { get; protected set; }
        public virtual void Deposita(double valorOperacao)
        {
            this.Saldo += valorOperacao;
        }
        public virtual void Saca(double valor)
            {
                this.Saldo -= valor;
            }
        }
    }
// Capitulo 10 tópico 4 questão 1; RESPOSTA: Só a própria classe enxerga atributos/métodos private enquanto protected é visto pela própria classe mais as classes filhas.
//Capitulo 10 tópico 4 questão 2; RESPOSTA:Para indicar que o método está sobrescrevendo um método da classe pai.
// Capitulo 10 tópico 4 questão 3; RESPOSTA:Para permitir que o método seja sobrescrito
