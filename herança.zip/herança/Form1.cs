﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace herança
{
    public partial class Form1 : Form
    {
        private Conta conta;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) //capitulo 10 topico 4 questão 5; RESPOSTA: conta poupança = 49.9 e conta = 50.0
        {
            Conta c1 = new ContaCorrente();//questão 7(ContaCorrente); a questão 5 seria(ContaPoupanca)
            c1.Deposita(100.0);
            c1.Saca(50.0);
            MessageBox.Show("conta poupança = " + c1.Saldo);

            Conta c2 = new Conta();
            c2.Deposita(100.0);
            c2.Saca(50.0);
            MessageBox.Show("conta = " + c2.Saldo);
            
            this.conta = new ContaPoupanca(); //questão 6
            this.conta.Deposita(200.0);
            MessageBox.Show("conta poupança = " + this.conta.Saldo);

        }
    }
}
